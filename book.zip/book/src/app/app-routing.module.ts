import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShowComponent } from './component/show/show.component';
import { SearchComponent } from './component/search/search.component';


const routes: Routes = [
  {path:'',redirectTo:'show',pathMatch:'full'},
   
    {path:'show',component : ShowComponent},
   
    {path:'search', component:SearchComponent},
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
