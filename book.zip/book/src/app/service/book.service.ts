import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Book} from '../model/book';

@Injectable({
  providedIn: 'root'
})
export class BookService {
  filtereddata:Book[];
  url:string="http://localhost:3000/book";

  constructor(private http:HttpClient) { }
    
   
  getAllBooks(){
    return this.http.get<Book[]>(this.url);   
  }
  setSearcheddata(searchedData:Book[]){
    this.filtereddata=searchedData;
     }
}
